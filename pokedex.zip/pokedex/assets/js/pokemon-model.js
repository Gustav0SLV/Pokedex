class Pokemon {
    number;
    name;
    type;
    types = [];
    photo;
}