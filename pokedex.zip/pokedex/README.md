# dio-js-developer-pokedex
Projeto didático de construção de uma Pokedex com Javascript

## Leiaute
![image](https://user-images.githubusercontent.com/2284408/197915630-d514391b-3b48-47ee-a52b-b10f9b0dc7df.png)

https://dribbble.com/shots/6540871-Pokedex-App

## PokeAPI
https://pokeapi.co/

Caso você queira aprender a fazer um projeto semelhante, [cadastre-se na DIO, clique aqui](https://dio.me/sign-up?ref=WH4RVZFWTA).

[![Linkedin](https://img.shields.io/badge/Made%20by-Tarcnux-deepskyblue)](https://www.linkedin.com/in/tarcnux)

[![Twitter](https://img.shields.io/twitter/follow/tarcnux?style=social)](https://www.twitter.com/tarcnux)
